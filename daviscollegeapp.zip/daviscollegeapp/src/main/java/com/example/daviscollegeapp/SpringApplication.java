package com.example.daviscollegeapp;

public class SpringApplication {
}
