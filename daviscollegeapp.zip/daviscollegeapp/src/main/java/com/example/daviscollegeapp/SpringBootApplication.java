package com.example.daviscollegeapp;

public @interface SpringBootApplication {

}
